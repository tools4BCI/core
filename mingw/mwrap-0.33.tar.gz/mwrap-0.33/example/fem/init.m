if ~exist('femex'), addpath([pwd, '/mwfem']); end
